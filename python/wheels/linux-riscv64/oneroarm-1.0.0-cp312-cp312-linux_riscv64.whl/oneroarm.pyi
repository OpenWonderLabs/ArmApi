"""
Onero Robot Arm API Python Bindings via pybind11
"""
from enum import IntEnum
from typing import overload, Any, Callable, Optional

class JointArray:
    """
    Represents an array of joint values (fixed-length, typically 7-DOF).
    """
    def __init__(self) -> None: ...
    def __len__(self) -> int: ...
    def __getitem__(self, index: int) -> float: ...
    def __setitem__(self, index: int, value: float) -> None: ...
    def __repr__(self) -> str: ...

class OneroConfig:
    """
    Configuration structure for the Onero Robot Arm.
    """
    device: str
    robot_model: str
    dof: int
    baud_rate: int
    urdf_path: str
    version: str
    mount_orientation: str
    """Installation orientation: "horizontal" or "vertical" (default "vertical")."""
    mit_kp: list[float]
    """MIT-mode PD proportional gains (length up to 7, one per joint)."""
    mit_kd: list[float]
    """MIT-mode PD derivative gains (length up to 7, one per joint)."""
    model_description_path: str
    """onero_description 资源根目录。留空 -> 走 SDK 内置；非空时优先级最高，可被 ONERO_DESCRIPTION_PATH/DIR 环境变量覆盖。"""
    with_gripper: bool
    """Enable the optional arm-owned gripper on the same CAN bus."""

    def __init__(self) -> None: ...

class Pose:
    """
    Represents a Cartesian pose (Position + Orientation).
    """
    x: float
    y: float
    z: float
    qw: float
    qx: float
    qy: float
    qz: float

    def __init__(self) -> None: ...

class ForcePosition:
    """
    Parameters for force-position control.
    """
    force_position_flag: bool
    direction: int
    force: float

    def __init__(self) -> None: ...

class ArmStateFromMotor:
    """
    Arm state read from motors.
    """
    positions: JointArray
    velocities: JointArray
    torques: JointArray

    def __init__(self) -> None: ...

class GripperStatus:
    """
    Optional gripper state. Position and velocity are expressed in percent units.
    """
    position: float
    velocity: float
    force: float
    error: int
    valid: bool

    def __init__(self) -> None: ...

class TrajectoryPoint:
    """
    Trajectory point with joint position, velocity and acceleration.
    """
    position: JointArray
    velocity: JointArray
    acceleration: JointArray

    def __init__(self) -> None: ...

class DragTeachingState(IntEnum):
    """
    Drag-teaching state machine values.
    """
    IDLE      = 0
    RECORDING = 1
    REPLAYING = 2

class MoveResult(IntEnum):
    """
    Motion API result codes.
    """
    SUCCESS              = 0
    INVALID_PARAMS       = -1
    IK_FAILED            = -2
    COLLISION_DETECTED   = -3
    EXECUTION_FAILED     = -4
    TIMEOUT              = -5
    INTERRUPTED          = -6
    JOINT_LIMIT_EXCEEDED = -7
    BUSY                 = -8

ONERO_OK: int = 0
ONERO_ERR_INVALID_PARAMS: int = -1
ONERO_ERR_IK_FAILED: int = -2
ONERO_ERR_COLLISION_DETECTED: int = -3
ONERO_ERR_EXECUTION_FAILED: int = -4
ONERO_ERR_TIMEOUT: int = -5
ONERO_ERR_INTERRUPTED: int = -6
ONERO_ERR_JOINT_LIMIT_EXCEEDED: int = -7
ONERO_ERR_BUSY: int = -8

ONERO_CAN_OK: int = 0
ONERO_ERR_RAW_FRAME_INVALID_LEN: int = -10
ONERO_ERR_RAW_FRAME_INVALID_ID: int = -11
ONERO_ERR_RAW_FRAME_RESERVED_ID: int = -12
ONERO_ERR_RAW_FRAME_PORT_NOT_OPEN: int = -13
ONERO_ERR_RAW_FRAME_SEND_FAILED: int = -14

class OneroGripper:
    """
    Arm-owned optional gripper controller. Created as OneroArm.gripper.
    force_control torque is limited to +/-40 N.
    """
    def enable(self) -> bool: ...
    def disable(self) -> bool: ...
    def status(self) -> GripperStatus: ...
    def set_position(self, percent: float) -> int: ...
    def move_position(
        self,
        percent: float,
        max_vel: float = 100.0,
        max_acc: float = 250.0,
        max_jerk: float = 1000.0,
    ) -> int: ...
    def force_control(self, torque: float) -> int: ...

class OneroArm:
    """
    Main interface for controlling the Onero Robot Arm.
    """
    gripper: Optional[OneroGripper]

    def __init__(self, config: OneroConfig, with_gripper: bool = False) -> None:
        """
        Initialize the OneroArm with the given configuration.
        """
        ...

    def has_gripper(self) -> bool:
        """
        Whether this arm was initialized with the optional gripper.
        """
        ...

    def enable_motors(self) -> bool:
        """
        Enable the robot motors. Returns True on success.
        """
        ...

    def disable_motors(self) -> bool:
        """
        Disable the robot motors. Returns True on success.
        """
        ...

    @overload
    def restore_arm(self) -> int:
        """
        Move the robot back to its default zero pose at a safe speed.
        """
        ...

    @overload
    def restore_arm(self, target: JointArray | list[float]) -> int:
        """
        Move the robot to a specific joint target at a safe speed.
        """
        ...

    def movej(self,
              target: JointArray | list[float],
              speed_scale: float = 1.0,
              trajectory_connect: int = 0) -> int:
        """
        Move joints to target positions.
        """
        ...

    def movel(self,
              pose: Pose,
              speed_scale: float = 1.0,
              trajectory_connect: int = 0) -> int:
        """
        Move end-effector linearly to target pose.
        """
        ...

    def movep(self,
              pose: Pose,
              speed_scale: float = 1.0,
              trajectory_connect: int = 0) -> int:
        """
        Move via point (Path movement).
        """
        ...

    def force_position_movel(self,
                             pose: Pose,
                             speed_scale: float = 1.0,
                             trajectory_connect: int = 0) -> int:
        """
        Move linearly with force-position mode.
        """
        ...

    def estimate_movej_duration(self,
                                target: JointArray | list[float],
                                speed_scale: float = 1.0) -> float:
        """
        Estimate the MoveJ duration without executing motion.
        """
        ...

    def get_joint_positions(self) -> JointArray:
        """
        Get the current calculated joint positions.
        """
        ...

    def get_joint_positions_from_motors(self) -> JointArray:
        """
        Get the actual joint positions read from motors.
        """
        ...

    def get_joint_velocities(self) -> JointArray:
        """
        Get the current joint velocities.
        """
        ...

    def get_arm_state_from_motor(self) -> ArmStateFromMotor:
        """
        Get joint positions, velocities and torques from motors.
        """
        ...

    def get_arm_state_cached(self) -> ArmStateFromMotor:
        """
        Get the latest cached arm state without triggering CAN I/O.

        The cache is refreshed by the active control loop after every command,
        so upper-level scripts can poll state without contending on the motor
        bus. If the cache has never been written, this returns an empty state.
        """
        ...

    def get_end_effector_pose(self) -> Pose:
        """
        Get the current Cartesian pose of the end effector.
        """
        ...

    def get_end_effector_pose_cached(self) -> Pose:
        """
        Get the latest cached end-effector pose without triggering CAN I/O.
        """
        ...

    def send_trajectory_point(self, q: JointArray, dq: JointArray) -> int:
        """
        Send a single trajectory point (position and velocity) to the buffer.
        """
        ...

    def execute_buffered_trajectory(self) -> int:
        """
        Execute the trajectory currently stored in the buffer.
        """
        ...

    def clear_trajectory_buffer(self) -> int:
        """
        Clear the trajectory buffer.
        """
        ...

    def reset_stop_signal(self) -> None:
        """
        Clear a previously latched stop/interruption signal before issuing a new command.
        """
        ...

    def set_force_position_control(self, force_position: ForcePosition) -> int:
        """
        Start force-position control with the given parameters.
        """
        ...

    def stop_force_position_control(self) -> int:
        """
        Stop force-position control.
        """
        ...

    def send_trajectory(self, trajectory: list[TrajectoryPoint]) -> int:
        """
        Submit a list of trajectory points (position/velocity/acceleration)
        for execution. Returns 0 on success.
        """
        ...

    def cancel_trajectory(self) -> int:
        """
        Cancel any in-flight trajectory execution. Returns 0 on success.
        """
        ...

    def is_hardware_connected(self) -> bool:
        """
        Whether the underlying motor bus is currently online.
        """
        ...

    # ---------------- Raw CAN Frame API ---------------- #

    def send_can_frame(self, can_id: int, payload: bytes) -> int:
        """
        Send a custom CAN frame. payload is any bytes-like object
        (bytes / bytearray / memoryview), length must be <= 8.
        Returns 0 on success or a negative error code.
        """
        ...

    def register_can_frame_callback(
        self,
        callback: Optional[Callable[[int, bytes], None]],
    ) -> int:
        """
        Register a callback(can_id, payload_bytes) for non-reserved inbound
        frames. Re-registering replaces the previous callback; passing None
        clears it (equivalent to clear_can_frame_callback()).
        """
        ...

    def clear_can_frame_callback(self) -> int:
        """Clear any registered raw-CAN inbound callback."""
        ...

    def pump_can_bus(self, timeout_ms: int) -> int:
        """
        Drive inbound frame dispatch for up to timeout_ms ms
        (0 means a single non-blocking poll). Returns 0 on success.
        """
        ...


class OneroDragTeaching:
    """
    Drag-teaching helper. Records joint trajectories from physical
    back-driving and replays them.
    """
    def __init__(self) -> None: ...

    def initialize(self,
                   dof: int,
                   record_file: str,
                   time_step: float = 0.01) -> bool:
        """
        Configure recording dof, output file path and sampling step.
        """
        ...

    def set_hardware(self,
                     device: str,
                     urdf_path: str,
                     robot_model: str,
                     mount_orientation: str = "horizontal") -> bool:
        """
        Bind the drag-teaching session to a hardware device.
        """
        ...

    def enable_motors(self) -> int:
        """
        Enable motors for drag teaching without moving the arm.
        """
        ...

    @overload
    def restore_arm(self) -> int:
        """
        Move the arm back to its zero pose at a safe speed.
        """
        ...

    @overload
    def restore_arm(self, target: JointArray | list[float]) -> int:
        """
        Move the arm to a specific joint target at a safe speed.
        """
        ...

    def start_recording(self) -> int:
        """Start recording joint trajectory."""
        ...

    def stop_recording(self) -> int:
        """Stop recording and finalize the output file."""
        ...

    def set_replay_file(self, replay_file: str) -> None:
        """Select the file used by start_replay()."""
        ...

    def start_replay(self) -> int:
        """Start replaying the previously selected file."""
        ...

    def stop_replay(self) -> int:
        """Stop replay if it is running."""
        ...

    def handle_command(self, cmd: int) -> int:
        """Forward a UI command code to the drag-teaching state machine."""
        ...

    @staticmethod
    def handle_command_dual(left: "OneroDragTeaching",
                            right: "OneroDragTeaching",
                            cmd: int) -> int:
        """
        Forward a UI command code to two drag-teaching sessions.
        cmd=1/3 uses the SDK-side synchronized dual-arm path.
        """
        ...

    def timer_callback(self) -> None:
        """Periodic tick to advance recording or replay."""
        ...

    def get_state(self) -> DragTeachingState:
        """Return the current drag-teaching state."""
        ...

    def is_initialized(self) -> bool:
        """Whether initialize()/set_hardware() have been called successfully."""
        ...

    def update_joint_state(self,
                           position: JointArray,
                           velocity: JointArray,
                           effort: JointArray) -> None:
        """
        Push the latest measured joint state to the drag-teaching pipeline.
        Typically called from the control loop's sensor callback.
        """
        ...
